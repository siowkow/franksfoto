<?php

/*

// Example

$items = array();

$items[] = array( 'title' 	=> 'Other page',
				  'target' 	=> 'content',
				  'link'	=> 'http://www.google.de');

$items[] = array( 'title' 	=> 'Mailqueue',
				  'target' 	=> 'content',
				  'link'	=> 'tools/mailqueue.php');


$module['nav'][] = array(	'title'	=> 'System Info',
							'open' 	=> 1,
							'items'	=> $items);


*/

?>