<?php
$module["name"] 		= "login";
$module["title"] 		= "top_menu_login";
$module["template"] 	= "module.tpl.htm";
$module["startpage"] 	= "login/index.php";
?>